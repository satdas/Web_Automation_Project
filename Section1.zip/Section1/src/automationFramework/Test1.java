package automationFramework;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;


public class Test1 {
	WebDriver driver;
  @Test
  public void Check_value_in_another_dropdown_based_on_value_selected_in_one_dropdpwn() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "Chrome Driver executable location on your system"); 
      System.out.println("Execution after setting ChromeDriver path in System setProperty method");
      System.setProperty("webdriver.chrome.driver", "C:\\Users\\Satyabrata\\Downloads\\chromedriver_win32\\chromedriver.exe");
      driver = new ChromeDriver();
		System.out.println("Execution after setting ChromeDriver path in System Variables");
		 //driver.get("https://www.moneycontrol.com/");
		driver.get("https://www.moneycontrol.com/mf/returns-calculator.php");
		Select mf = new Select(driver.findElement(By.id("ff_id")));
		mf.selectByVisibleText("Aditya Birla Sun Life Mutual Fund");
		
		@SuppressWarnings("deprecation")
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.id("im_id")));
		Select scheme = new Select(element);
		List<WebElement> options = scheme.getOptions();
		Assert.assertEquals("Aditya Birla Sun Life Active Debt Multi Manager FoF Scheme (D)",options.get(3).getText());
		
		
		
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
  }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }
  

}
