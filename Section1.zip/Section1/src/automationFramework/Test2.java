package automationFramework;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;


public class Test2 {
	WebDriver driver;
  @Test
  public void check_aboutus_page_text() {
	  System.setProperty("webdriver.chrome.driver", "Chrome Driver executable location on your system"); 
      System.out.println("Execution after setting ChromeDriver path in System setProperty method");
      System.setProperty("webdriver.chrome.driver", "C:\\Users\\Satyabrata\\Downloads\\chromedriver_win32\\chromedriver.exe");
       driver = new ChromeDriver();
		System.out.println("Execution after setting ChromeDriver path in System Variables");
		 driver.get("https://finartis.com");
		 //Thread.sleep(3000);
		 WebElement aboutus = driver.findElement(By.linkText("About us"));
	   	 aboutus.click();
	   	WebElement officeloc = driver.findElement(By.xpath("//*[@id='section-offices']/div[4]/div[2]/h4"))	;
	   	System.out.println(officeloc.getText());
	   	Assert.assertEquals("Singapore",officeloc.getText());
		 
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
  }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }
  

}
