package automationFramework;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;


public class Test3 {
	WebDriver driver;
  @Test
  public void Check_text_appearing_in_page_after_clicking_submenu_under_menu() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "Chrome Driver executable location on your system"); 
      System.out.println("Execution after setting ChromeDriver path in System setProperty method");
      System.setProperty("webdriver.chrome.driver", "C:\\Users\\Satyabrata\\Downloads\\chromedriver_win32\\chromedriver.exe");
         	driver = new ChromeDriver();
	   	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	      //URL launch
	      driver.get("https://www.amazon.com/");
	      //identify menu
	      WebElement n=driver.findElement(By.id("nav-link-accountList"));
	      // object of Actions with method moveToElement
	      Actions a = new Actions(driver);
	      a.moveToElement(n).perform();
	      //identify sub-menu element
	      WebElement m=driver.findElement(By.xpath("//*[text()='Create a List']"));
	      
	      //move to element and click
	      a.moveToElement(m).click().perform();
	      Assert.assertEquals("Your List",driver.getTitle());
	      WebElement txt = driver.findElement(By.xpath("//*[text()='Shopping List']"));
	      Assert.assertEquals("Shopping List",txt.getText());
		
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting Test On Chrome Browser");
  }

  @AfterMethod
  public void afterMethod() {
	  driver.close();
	  System.out.println("Finished Test On Chrome Browser");
  }
  

}
